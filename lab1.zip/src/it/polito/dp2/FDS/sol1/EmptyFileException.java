package it.polito.dp2.FDS.sol1;

public class EmptyFileException extends Exception{

	EmptyFileException()
	{
		super();
	}
	
	EmptyFileException(String msg)
	{
		super(msg);
	}
}
